import { Component, OnInit } from '@angular/core';
import { NotesService, Note } from '../services/notes.service';
import { ActionSheetController } from '@ionic/angular';

@Component({
  selector: 'app-todo-tab',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit {

  newNoteContent: string = '';
  editingNote: Note | null = null;

  constructor(
    public notesService: NotesService,
    public actionSheetController: ActionSheetController
  ) { }

  async ngOnInit() {
    await this.notesService.loadNotes();
  }

  addNote() {
    if (this.newNoteContent.trim()) {
      if (this.editingNote) {
        // Create a new note object with updated content
        const updatedNote: Note = {
          ...this.editingNote,
          content: this.newNoteContent
        };
        this.notesService.updateNote(updatedNote);
        this.editingNote = null;
      } else {
        this.notesService.addNote(this.newNoteContent);
      }
      this.newNoteContent = '';
    }
  }

  public async showActionSheet(note: Note) {
    const actionSheet = await this.actionSheetController.create({
      header: 'Note',
      buttons: [{
        text: 'Edit',
        icon: 'create',
        handler: () => {
          this.editNote(note);
        }
      }, {
        text: 'Delete',
        role: 'destructive',
        icon: 'trash',
        handler: () => {
          this.notesService.deleteNote(note.id);
        }
      }, {
        text: 'Cancel',
        icon: 'close',
        role: 'cancel',
        handler: () => {
          // Nothing to do, action sheet is automatically closed
        }
      }]
    });
    await actionSheet.present();
  }

  async editNote(note: Note) {
    this.editingNote = note;
    this.newNoteContent = note.content;
  }
}
