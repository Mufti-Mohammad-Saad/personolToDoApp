import { Injectable } from '@angular/core';
import { Preferences } from '@capacitor/preferences';

@Injectable({
  providedIn: 'root'
})
export class NotesService {
  private NOTES_STORAGE: string = 'notes';
  public notes: Note[] = [];

  constructor() { }

  async loadNotes() {
    const { value } = await Preferences.get({ key: this.NOTES_STORAGE });
    this.notes = value ? JSON.parse(value) : [];
  }

  async addNote(content: string) {
    const newNote: Note = {
      id: Date.now(),
      content
    };
    this.notes.push(newNote);
    await this.saveNotes();
  }
  
 
  async updateNote(updatedNote: Note) {
    // Find the index of the note to update
    const index = this.notes.findIndex(note => note.id === updatedNote.id);
    
    if (index !== -1) {
      // Update the note content
      this.notes[index] = updatedNote;
      // Save the updated notes
      await this.saveNotes();
    }
  }


  async deleteNote(noteId: number) {
    this.notes = this.notes.filter(note => note.id !== noteId);
    await this.saveNotes();
  }

  private async saveNotes() {
    await Preferences.set({
      key: this.NOTES_STORAGE,
      value: JSON.stringify(this.notes)
    });
  }
}

export interface Note {
  id: number;
  content: string;
}
