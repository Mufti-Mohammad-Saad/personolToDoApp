# personolToDoApp
this file is just to take notes and images for short term tasks
